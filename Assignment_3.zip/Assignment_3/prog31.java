class Student{
	private int rno;
	private String name;
	void setData(int sno,String sname)
	{
		rno=sno;
		name=sname;
	}
	void showData()
	{
		System.out.println("Roll_No = "+rno+"\nName = "+name);
	}
}

public class prog31{
	public static void main(String[] args){
		Student s = new Student();
		
		s.setData(101,"Shubham");
		s.showData();
	}
}
/*
C:\Users\swapn\JAVA\Assignment_3>javac prog31.java

C:\Users\swapn\JAVA\Assignment_3>java prog31
Roll_No = 101
Name = Shubham

C:\Users\swapn\JAVA\Assignment_3>
*/