import java.util.Scanner;
class prog27{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of array:");
		int row=sc.nextInt();
		int arr[]=new int[row];
		System.out.println("Enter the Element:");
		for(int i=0;i<row;i++)
		{			
			arr[i]=sc.nextInt();
		}
		System.out.println("**************Element in Array**********");
		for(int i=0;i<row;i++)
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println("");
		int greatest=arr[0];
		int smallest=arr[0];
		for(int i=0;i<row;i++)
		{
			if(arr[i]>greatest)
			{
				greatest=arr[i];
			}
			else if(arr[i]<smallest)
			{
				smallest=arr[i];
			}
		}
		System.out.println("Greatest Element in Array = "+greatest);
		System.out.println("Smallest Element in Array = "+smallest);
	}
}
/*
C:\Users\swapn\JAVA\Assignment_3>javac prog27.java

C:\Users\swapn\JAVA\Assignment_3>java prog27
Enter the size of array:
5
Enter the Element:
15
5
60
12
30
**************Element in Array**********
15 5 60 12 30
Greatest Element in Array = 60
Smallest Element in Array = 5

C:\Users\swapn\JAVA\Assignment_3>
*/