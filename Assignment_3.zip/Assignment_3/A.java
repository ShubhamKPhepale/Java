class A{
	static int x=10;
	public static void main(String args[]){
		String[] colors={"Red","Yellow","White"};
		System.out.println(colors[2]);
	}
}