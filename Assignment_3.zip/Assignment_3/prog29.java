import java.util.*;
class prog29{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the row size:");
		int row=sc.nextInt();
		int arr1[]=new int[row];
		int arr[][]=new int[row][];
		System.out.println("Enter the Element in 2-D array");
		for(int i=0;i<row;i++)
		{
			System.out.println("Enter the how many column u want::");
			int col=sc.nextInt();
			arr[i] = new int[col];
			for(int j=0;j<arr[i].length;j++)
			{
				System.out.println("Enter the Element:");
				arr[i][j]=sc.nextInt();
			}
		}
		System.out.println("**************Element in Tow-D Array**********");
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				System.out.print(" "+arr[i][j]);
			}
			System.out.println("");
		}
		System.out.println("Enter the Element in 1-D array");
		for(int i=0;i<row;i++)
		{			
			arr1[i]=sc.nextInt();
		}
		System.out.println("**************Element in one-D Array**********");
		for(int i=0;i<row;i++)
		{
			System.out.print(arr1[i]+" ");
		}
		System.out.println("");
		
		int count=0;
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				if(arr1[i]==arr[i][j])
				{
					count++;
				}	
			}
		}
		System.out.println("Count = "+count);
		if(count==row)
		{
			System.out.println("One-D Array Element is present in Two-D Array");
		}
		else
		{
			System.out.println("One-D Array Element is Not present in Two-D Array");
		}
		
	}
}