import java.util.Scanner;
class prog26{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the row size:");
		int row=sc.nextInt();
		int arr[][]=new int[row][];
		for(int i=0;i<row;i++)
		{
			System.out.println("Enter the how many column u want::");
			int col=sc.nextInt();
			arr[i] = new int[col];
			for(int j=0;j<arr[i].length;j++)
			{
				System.out.println("Enter the Element:");
				arr[i][j]=sc.nextInt();
			}
		}
		System.out.println("**************Element in Array**********");
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				System.out.print(" "+arr[i][j]);
			}
			System.out.println("");
		}
		int sum=0;
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				sum=sum+arr[i][j];
			}
		}
		System.out.println("Sum of Element in Array = "+sum);
	}
}

/*
C:\Users\swapn\JAVA\Assignment_3>javac prog26.java

C:\Users\swapn\JAVA\Assignment_3>java prog26
Enter the row size:
5
Enter the how many column u want::
3
Enter the Element:
1
Enter the Element:
2
Enter the Element:
3
Enter the how many column u want::
4
Enter the Element:
4
Enter the Element:
5
Enter the Element:
6
Enter the Element:
7
Enter the how many column u want::
3
Enter the Element:
9
Enter the Element:
8
Enter the Element:
7
Enter the how many column u want::
4
Enter the Element:
6
Enter the Element:
5
Enter the Element:
4
Enter the Element:
3
Enter the how many column u want::
3
Enter the Element:
1
Enter the Element:
2
Enter the Element:
3
**************Element in Array**********
 1 2 3
 4 5 6 7
 9 8 7
 6 5 4 3
 1 2 3
Sum of Element in Array = 76

C:\Users\swapn\JAVA\Assignment_3>
*/