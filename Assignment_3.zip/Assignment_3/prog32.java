class Student{
	private int rno;
	private String name;
	public static int count;
	void setData(int sno,String sname)
	{
		rno=sno;
		name=sname;
	}
	void showData()
	{
		System.out.println("Roll_No = "+rno+"\nName = "+name);
		count++;
		System.out.println("No of Object created = "+count);
	}
}

public class prog32{
	public static void main(String[] args){
		Student s1 = new Student();
		Student s2 = new Student();
		Student s3 = new Student();
		Student s4 = new Student();
		Student s5 = new Student();
		
		s1.setData(101,"Sandy");
		s2.setData(102,"Sammy");
		s3.setData(103,"Rahul");
		s4.setData(104,"Akshay");
		s5.setData(105,"Shubham");
			
		s1.showData();
		s2.showData();
		s3.showData();
		s4.showData();
		s5.showData();
	}
}