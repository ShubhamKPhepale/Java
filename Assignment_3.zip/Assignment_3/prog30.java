import java.util.Scanner;
class prog30{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		
		int arr[][]=new int[3][3];
		for(int i=0;i<arr.length;i++)
		{
			System.out.println("Enter the Element in Row "+(i+1));
			for(int j=0;j<arr[i].length;j++)
			{
				
				arr[i][j]=sc.nextInt();
			}
		}
		System.out.println("**************Element in Array**********");
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				System.out.print(" "+arr[i][j]);
			}
			System.out.println("");
		}
		int sum=0;
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				if(i==j)
				{
					sum=sum+arr[i][j];
				}
				
			}
		}
		System.out.println("Sum of Element Array in Diagonal = "+sum);
	}
}

/*
C:\Users\swapn\JAVA\Assignment_3>javac prog30.java

C:\Users\swapn\JAVA\Assignment_3>java prog30
Enter the Element in Row 1
10
20
30
Enter the Element in Row 2
40
50
60
Enter the Element in Row 3
70
80
90
**************Element in Array**********
 10 20 30
 40 50 60
 70 80 90
Sum of Element Array in Diagonal = 150

C:\Users\swapn\JAVA\Assignment_3>
*/
