import java.util.*;
class prog28{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of array:");
		int size=sc.nextInt();
		String arr[]=new String[size];
		System.out.println("Enter the Element:");
		for(int i=0;i<size;i++)
		{			
			arr[i]=sc.next();
		}
		for(String str : arr)
		{
			System.out.println("String is = "+str);
		}
	}
}

/*
C:\Users\swapn\JAVA\Assignment_3>javac prog28.java

C:\Users\swapn\JAVA\Assignment_3>java prog28
Enter the size of array:
5
Enter the Element:
shubham
khandu
phepale
from
kopagraon
String is = shubham
String is = khandu
String is = phepale
String is = from
String is = kopagraon

C:\Users\swapn\JAVA\Assignment_3>
*/