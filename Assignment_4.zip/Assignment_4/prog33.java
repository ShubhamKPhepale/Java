class Student{
	private int rno;
	private String name;


	Student(int rno,String name)
	{
		this.rno=rno;
		this.name=name;
	}
	/*void setData(int sno,String sname)
	{
		this.rno=sno;
		this.name=sname;
	}*/
	void showData()
	{
		System.out.println("Roll_No = "+rno+"\nName = "+name);
	}
}

public class prog33{
	public static void main(String[] args){
		Student s = new Student(101,"Shubham");
		
		//s.setData(101,"Shubham");
		s.showData();
	}
}