import java.util.*;
class Product{
	int pid;
	int price;
	int quntity;
	static int a=100;
	Product(int pid,int price,int quntity)
	{
		this.pid=pid;
		this.price=price;
		this.quntity=quntity;
	}
	
	static int TotalPro(Product p[])
	{
		int max=0;
		for(int i=0;i<p.length;i++)
		{
			max=max+p[i].price * p[i].quntity;
		}
		return max;
	}
}

class prog39{
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter How many object u want:");
		int obj=sc.nextInt();
		Product p[]=new Product[obj];
		for(int i=0;i<obj;i++)
		{
			System.out.println("Enter the PID:");
			int pid=sc.nextInt();
			System.out.println("Enter the Price:");
			int price=sc.nextInt();
			System.out.println("Enter the Quntity:");
			int quntity=sc.nextInt();	
			Product p1=new Product(pid,price,quntity);
			
			p[i]=p1;
		}
		
		int maxprice=0;
		int maxpid=0;
		for(int i=0;i<p.length;i++)
		{
			maxprice=p[0].price;
			if(p[i].price >=maxprice)
			{
				maxpid=p[i].pid;
			}
		}
		System.out.println("Product id with Highest price = "+maxpid);
		int result=Product.TotalPro(p);
		System.out.println("Total Amount Spent on all Product = "+result);
		
	}
}