class Employee{
	private int empId;
	private String empName;
	Employee(){		
		//this(101,"shubham");
	}
	Employee(int empId,String empName){
		this();
		this.empId = empId;
		this.empName = empName;
		
	}
	void show(){
		System.out.println("ID = "+empId+"\nName = "+empName);
	}
}
class prog41{
	public static void main(String args[]){
		Employee e = new Employee(1,"shubham");
		e.show();
		
	}
}
