class Employee{
	private int empNo;
	private double salary;
	static double totalsalary;
	static int empcount=0;
	Employee(double salary)
	{
		this.salary=salary;
		empNo=empNo+1;
		
		this.totalsalary=totalsalary+salary;
		empcount++;
	}
	void showData()
	{
		System.out.println("Employee id = "+empNo);
		System.out.println("Employee Salary = "+salary);
	}
	
	void TotalSal()
	{
		System.out.println("Toatal Salary of Employees = "+totalsalary);
		System.out.println("Total Number of Employee = "+empcount);
	}
}

class prog