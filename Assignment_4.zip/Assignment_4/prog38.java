import java.util.*;
class Employee{
	private static int empNo;
	private static double salary;
	static double totalsalary;
	static int empcount=0;
	Employee(double salary)
	{
		this.salary=salary;
		empNo++;
		
		this.totalsalary=totalsalary+salary;
		empcount++;
	}
	void showData()
	{
		System.out.println("Employee id = "+empNo);
		System.out.println("Employee Salary = "+salary);
	}
	
	void TotalSal()
	{
		System.out.println("Toatal Salary of Employees = "+totalsalary);
		System.out.println("Total Number of Employee = "+empcount);
	}
}

class prog38{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Salary of Employee");
		double sal1=sc.nextDouble();
		Employee e1 = new Employee(sal1);
		e1.showData();
		System.out.println("Enter the Salary of Employee");
		double sal2=sc.nextDouble();
		Employee e2 = new Employee(sal2);
		e2.showData();
		System.out.println("Enter the Salary of Employee");
		double sal3=sc.nextDouble();
		Employee e3 = new Employee(sal3);
		
		e3.showData();
		e3.TotalSal();
	}
}

/*
C:\Users\swapn\JAVA\Assignment_4>javac prog38.java

C:\Users\swapn\JAVA\Assignment_4>java prog38
Enter the Salary of Employee
5000
Employee id = 1
Employee Salary = 5000.0
Enter the Salary of Employee
3000
Employee id = 2
Employee Salary = 3000.0
Enter the Salary of Employee
6000
Employee id = 3
Employee Salary = 6000.0
Toatal Salary of Employees = 14000.0
Total Number of Employee = 3

C:\Users\swapn\JAVA\Assignment_4>
*/