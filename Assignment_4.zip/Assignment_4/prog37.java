class Person{
	private int age;
	private String name;
	
	Person(){
		this.age=18;
		this.name="Sandy";
		System.out.println("Default Ages is = "+age);
		System.out.println("Name = "+name);
	}
	
	Person(int age,String name)
	{
		this.age=age;
		this.name=name;
	}
	
	void showData()
	{
		System.out.println("Ages of person is = "+age);
		System.out.println("Name of person is = "+name);
	}
}
public class prog37{
	public static void main(String[] args){
		Person p1=new Person();
		Person p2=new Person(23,"Shubham");
		
		p2.showData();
	}
}
/*
C:\Users\swapn\JAVA\Assignment_4>javac prog37.java

C:\Users\swapn\JAVA\Assignment_4>java prog37
Default Ages is = 18
Name = Sandy
Ages of person is = 23
Name of person is = Shubham

C:\Users\swapn\JAVA\Assignment_4>
*/