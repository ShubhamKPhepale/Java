import java.util.*;
class Circle{
	private int r;
	private double area;
	private double pi=3.14d;
	
	public void init(int r)
	{
		this.r=r;
	}
	public void calArea()
	{
		area=pi*r*r;
	}
	
	public void showData()
	{
		System.out.println("Area of Circle = "+area);
	}
}

public class prog34{
	public static void main(String[] args){
		Circle c = new Circle();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Radius of Circle");
		int r1=sc.nextInt();
		c.init(r1);
		c.calArea();
		c.showData();
	}
}
/*
C:\Users\swapn\JAVA\Assignment_3>javac prog34.java

C:\Users\swapn\JAVA\Assignment_3>java prog34
Enter Radius of Circle
5
Area of Circle = 78.5

C:\Users\swapn\JAVA\Assignment_3>
*/