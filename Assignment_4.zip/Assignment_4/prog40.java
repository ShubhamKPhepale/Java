import java.util.*;
class Student{

	private String name;
	private int rollNo;
	private int age;
	int score;
	void setData(String name,int rollNo,int age,int score)
	{
		this.name=name;
		this.rollNo=rollNo;
		this.age=age;
		this.score=score;
	}
	void showData()
	{
		System.out.println("Name = "+name+"\nrollNo = "+rollNo+"\nAge = "+age+"\nScore = "+score);
	}
}

class prog40{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter how many object you want");
		int obj=sc.nextInt();
		Student s[] = new Student[obj];
		for(int i=0;i<s.length;i++)
		{
			System.out.println("Enter Your name = ");
			String name=sc.next();
			
			System.out.println("Enter Your RollNo = ");
			int rollNo=sc.nextInt();
			
			System.out.println("Enter Your Age = ");
			int age=sc.nextInt();
			
			System.out.println("Enter Your Score = ");
			int score=sc.nextInt();
			
			Student st1=new Student();
			st1.setData(name,rollNo,age,score);
			s[i]=st1;
		}
		
		for(int i=0;i<s.length;i++)
		{
			if(s[i].score>=0 && s[i].score <=50)
			{
				System.out.println("\nCategory one score [0-50]");
				s[i].showData();
			}
			
			else if(s[i].score >50 && s[i].score <=65)
			{
				System.out.println("\nCategory one score [50-65]");
				s[i].showData();
			}             

			else if(s[i].score >65 && s[i].score <=80)
			{
				System.out.println("\nCategory one score [65-80]");
				s[i].showData();
			}      

            else if(s[i].score >80 && s[i].score <=100)
			{
				System.out.println("\nCategory one score [80-100]");
				s[i].showData();
			}      

            else
            {
                System.out.println("Not valid in score");
                s[i].showData();
			}
		}
	}
}