import java.util.*;
class MathOpt{
	
	void Multiply(int n1,int n2)
	{
		int res=n1*n2 ;
		System.out.println("Multiplication = "+res);
	}
	void Multiply(float n1,float n2,float n3)
	{
		float res=n1*n2*n3;
		System.out.println("Multiplication = "+res);
	}
	void Multiply(int arr[])
	{
		int res=1;
		for(int i=0;i<arr.length;i++)
		{
			res=res*arr[i];
		}
		System.out.println("Multiplication = "+res);
	}

	void Multiply(double n1,int n2)
	{
		double res=n1*n2;
		System.out.println("Multiplication = "+res);
	}
}

public class prog36{
	public static void main(String[] args){
		MathOpt m = new MathOpt();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter values of a and b");
		int a=sc.nextInt();
		int b=sc.nextInt();
		System.out.println("************* Multiplication of function 1 *************");
		m.Multiply(a,b);
		
		System.out.println("Enter values of c,d and f");
		float c=sc.nextFloat();
		float d=sc.nextFloat();
		float f=sc.nextFloat();
		System.out.println("************* Multiplication of function 2 ************* ");
		m.Multiply(c,d,f);
		
		int array[]={1,2,3,4};
		System.out.println("************* Multiplication of function 3 ************* ");
		m.Multiply(array);
		
		System.out.println("Enter values of g and h");
		double g=sc.nextDouble();
		int h=sc.nextInt();
		
		System.out.println("************* Multiplication of function 4 ************* ");
		m.Multiply(g,h);
		
	}
}
/*
C:\Users\swapn\JAVA\Assignment_4>javac prog36.java

C:\Users\swapn\JAVA\Assignment_4>java prog36
Enter values of a and b
10
5
************* Multiplication of function 1 *************
Multiplication = 50
Enter values of c,d and f
5.2
3.5
2.4
************* Multiplication of function 2 *************
Multiplication = 43.68
************* Multiplication of function 3 *************
Multiplication = 24
Enter values of g and h
5.75
5
************* Multiplication of function 4 *************
Multiplication = 28.75

C:\Users\swapn\JAVA\Assignment_4>
*/