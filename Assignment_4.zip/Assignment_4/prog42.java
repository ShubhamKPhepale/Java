import java.util.*;
class Tile{
	private int length;
	
	public void setTile(int len){
		this.length=length;
	}
	
	public int TileArea(){
		return(this.length)*(this.length);
	}
}

class Floor{
	
	private int length;
	private int width;
	
	void setFloor(int length,int width){
		this.length=length;
		this.width=width;
	}
	
	public int FloorArea(){
		return this.length * this.width;
	}
	
	
	void totalTile(Tile t){
		double sqArea=t.TileArea();
		double flArea=FloorArea();
		double Totalarea=(flArea/sqArea);
		System.out.println("The No of Tiles Reqiure = "+Totalarea);
	}
	
}

class prog42{
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Side of Square");
		int sq=sc.nextInt();
		
		System.out.println("Enter the Length of Reactangle");
		int len=sc.nextInt();
		
		System.out.println("Enter the Width of Reactangle");
		int width=sc.nextInt();
		
		Tile t=new Tile();
		t.setTile(sq);
		
		Floor f=new Floor();
		f.setFloor(len,width);
		
		f.totalTile(t);
	}
}