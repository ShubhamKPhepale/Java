import java.util.*;
class MathOpt{
	
	static int Add(int a,int b)
	{
		return a+b;
	}
	static int sub(int a,int b)
	{
		return a-b;
	}
	static int Multiply(int a,int b)
	{
		return a*b;
	}
	static int power(int a,int n)
	{
		int p=1;
		for(int i=0;i<=n;i++)
			p*=a;
		return p;
	}
}

public class prog35{
	public static void main(String[] args){
		MathOpt m = new MathOpt();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter values of a and b");
		int a=sc.nextInt();
		int b=sc.nextInt();
		
		System.out.println("Addition = "+m.Add(a,b));
		System.out.println("Substraction = "+m.sub(a,b));
		System.out.println("Multiplication = "+m.Multiply(a,b));
		System.out.println("Enter Power range");
		int n=sc.nextInt();
		System.out.println("Power = "+m.power(a,n));
		
	}
}
/*
C:\Users\swapn\JAVA\Assignment_4>javac prog35.java

C:\Users\swapn\JAVA\Assignment_4>java prog35
Enter values of a and b
10
5
Addition = 15
Substraction = 5
Multiplication = 50
Enter Power range
3
Power = 10000

C:\Users\swapn\JAVA\Assignment_4>
*/