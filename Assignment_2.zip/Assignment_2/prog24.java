import java.util.*;
class prog24{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the No of Elements:");
		int n=sc.nextInt();
		int arr[]=new int[n];
		int flag=1;
		System.out.println("Enter the Elements:");
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("Element in Array");
		for(int i=0;i<n;i++)
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println("\nEnter which Elements you want ot search:");
		int search=sc.nextInt();
		for(int i=0;i<n;i++)
		{
			if(arr[i]==search)
			{
				flag=0;
				break;
			}
			
		}
		if(flag==0)
		{
			System.out.println("Element found ");
		}
		else
		{
			System.out.println("Element not found ");
		}
	}
}

/*
C:\Users\swapn\JAVA\Assignment_2>javac prog24.java

C:\Users\swapn\JAVA\Assignment_2>java prog24
Enter the No of Elements:
5
Enter the Elements:
12
41
63
52
10
Element in Array
12 41 63 52 10
Enter which Elements you want ot search:
63
Element found

C:\Users\swapn\JAVA\Assignment_2>java prog24
Enter the No of Elements:
5
Enter the Elements:
12
41
63
52
10
Element in Array
12 41 63 52 10
Enter which Elements you want ot search:
50
Element not found

C:\Users\swapn\JAVA\Assignment_2>
*/