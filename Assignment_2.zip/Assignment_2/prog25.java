import java.util.*;
class prog25
{

	public static void main(String args[])
	{
		Scanner scanner = new Scanner(System.in);

	    System.out.print("\nEnter the size of the Array = ");

	    int size = scanner.nextInt();

	    int array[] = new int[size];

	    int evensum = 0;
		int oddsum = 0;
		System.out.println("Enter the Elements:");
		for(int i = 0 ; i<array.length ; i++ )

		{
			array[i] = scanner.nextInt();
		}

		for(int i = 0 ; i<array.length ; i++)
		{

			if(array[i]%2==0)
			{
				evensum = evensum+ array[i] ;
			}
			else if(array[i]%2 !=0)
			{
				oddsum = oddsum+array[i] ;
			}
		}

		System.out.println("\nAddition of Even numbers =  " +evensum);
		System.out.println("\nAddition of  Odd numbers =  " +oddsum);
	}
}

/*
C:\Users\swapn\JAVA\Assignment_2>javac prog25.java

C:\Users\swapn\JAVA\Assignment_2>java prog25

Enter the size of the Array = 5
Enter the Elements:
21
10
15
20
30

Addition of Even numbers =  60

Addition of  Odd numbers =  36

C:\Users\swapn\JAVA\Assignment_2>
*/