import java.util.*;
class prog21{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Elements:");
		int sum=0;
		double avg=0;
		int arr[]=new int[10];
		int count=0;
		int len;
		
		for(int i=0;i<10;i++)
		{
			arr[i]=sc.nextInt();
			count++;
		}
		len=count;
		
		System.out.println("Element in Array");
		for(int i=0;i<10;i++)
		{
			System.out.print(arr[i]+" ");
			sum=sum+arr[i];
		}
		avg=(sum/len);
		System.out.println("\nSum = "+sum);
		System.out.println("Average = "+avg);
	}
}

/*
C:\Users\swapn\JAVA\Assignment_2>javac prog21.java

C:\Users\swapn\JAVA\Assignment_2>java prog21
Enter the Elements:
1
2
3
4
5
6
7
8
9
10
Element in Array
1 2 3 4 5 6 7 8 9 10
Sum = 55
Average = 5.0

C:\Users\swapn\JAVA\Assignment_2>
*/