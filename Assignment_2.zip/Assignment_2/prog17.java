import java.util.*;
class prog17{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the no:");
		int num=sc.nextInt();
		int res=0;
		while(num>0)
		{
			int n= num%10;
			res = res*10+n;
			num=num/10;
		}
		System.out.println("Reverse Number = "+res);
	}
}

/*
C:\Users\swapn\JAVA\Assignment_2>javac prog17.java

C:\Users\swapn\JAVA\Assignment_2>java prog17
Enter the no:
153
Reverse Number = 351

C:\Users\swapn\JAVA\Assignment_2>
*/