import java.util.*;
class prog18{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the no:");
		int num=sc.nextInt();
		int flag=1;
		for(int i=2;i<num/2;i++)
		{
			if((num%i) == 0)
			{
				flag=0;
				break;
			}
		}
		if(flag==1)
		{
			System.out.println("Number is Prime");
		}
		else
		{
			System.out.println("Number is Not Prime");
		}
		
		
	}
}
/*
C:\Users\swapn\JAVA\Assignment_2>javac prog18.java

C:\Users\swapn\JAVA\Assignment_2>java prog18
Enter the no:
35
Number is Not Prime

C:\Users\swapn\JAVA\Assignment_2>java prog18
Enter the no:
9
Number is Not Prime

C:\Users\swapn\JAVA\Assignment_2>java prog18
Enter the no:
5
Number is Prime

C:\Users\swapn\JAVA\Assignment_2>
*/