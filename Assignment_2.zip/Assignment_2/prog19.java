import java.util.*;
class prog19{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the nth series no:");
		int num=sc.nextInt();
		System.out.println("**************Series**************");
		for(int i=12;i<=num;i+=10)
		{
			System.out.println(i);
		}
	}
}

/*
Enter the nth series no:
100
**************Series**************
12
22
32
42
52
62
72
82
92

C:\Users\swapn\JAVA\Assignment_2>
*/