import java.util.*;
class prog22{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Elements:");
		int arr[]=new int[10];
		int temp=0;
		for(int i=0;i<10;i++)
		{
			arr[i]=sc.nextInt();
					
		}
		for(int i=0;i<10;i++)
		{
			for(int j=i+1;j<10;j++)
			{
				if(arr[i] < arr[j]) {    
                   temp = arr[i];    
                   arr[i] = arr[j];    
                   arr[j] = temp;    
               }     
			}
		}
		System.out.println("Element in Array in Descending Order");
		for(int i=0;i<10;i++)
		{
			System.out.print(arr[i]+" ");
		}	
	}
}
/*
C:\Users\swapn\JAVA\Assignment_2>javac prog22.java

C:\Users\swapn\JAVA\Assignment_2>java prog22
Enter the Elements:
20
14
36
74
85
96
58
47
69
41
Element in Array in Descending Order
96 85 74 69 58 47 41 36 20 14
C:\Users\swapn\JAVA\Assignment_2>
*/