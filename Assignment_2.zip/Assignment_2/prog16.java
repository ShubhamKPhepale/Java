import java.util.*;
class prog16{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the no:");
		int num=sc.nextInt();
		int Table;
		System.out.println("**************Table is**************");
		for(int i=1;i<=10;i++)
		{
			Table=num*i;
			System.out.println(Table);
		}
	}
}
/*
C:\Users\swapn\JAVA\Assignment_2>javac prog16.java

C:\Users\swapn\JAVA\Assignment_2>java prog16
Enter the no:
5
**************Table is**************
5
10
15
20
25
30
35
40
45
50

C:\Users\swapn\JAVA\Assignment_2>
*/