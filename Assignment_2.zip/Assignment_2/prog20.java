import java.util.*;
class prog20{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Start no:");
		int startpt=sc.nextInt();
		System.out.println("Enter the End no:");
		int endpt=sc.nextInt();
		int flag;
		
		while(startpt < endpt)
		{
			flag=0;
			for(int i=2;i<startpt/2;i++)
			{
				if((startpt%i) == 0)
				{
					flag=1;
					break;
				}
			}
			if(flag==0 && startpt!=0 && startpt!=1)
			{
				System.out.println("Prime Numbers is "+startpt);
			}
			startpt++;
		}
	}
}

/*
C:\Users\swapn\JAVA\Assignment_2>java prog20
Enter the Start no:
10
Enter the End no:
90
Prime Numbers is 11
Prime Numbers is 13
Prime Numbers is 17
Prime Numbers is 19
Prime Numbers is 23
Prime Numbers is 29
Prime Numbers is 31
Prime Numbers is 37
Prime Numbers is 41
Prime Numbers is 43
Prime Numbers is 47
Prime Numbers is 53
Prime Numbers is 59
Prime Numbers is 61
Prime Numbers is 67
Prime Numbers is 71
Prime Numbers is 73
Prime Numbers is 79
Prime Numbers is 83
Prime Numbers is 89

C:\Users\swapn\JAVA\Assignment_2>
*/