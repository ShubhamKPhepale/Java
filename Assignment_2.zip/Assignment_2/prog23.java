import java.util.*;
class prog23{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the No of Elements:");
		int n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter the Elements:");
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("Element in Array");
		for(int i=0;i<n;i++)
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println("\nElement in Reverse Order");
		for(int i=n-1;i>=0;i--)
		{
			System.out.print(arr[i]+" ");
		}
		
		
	}
}
/*
C:\Users\swapn\JAVA\Assignment_2>javac prog23.java

C:\Users\swapn\JAVA\Assignment_2>java prog23
Enter the No of Elements:
5
Enter the Elements:
10
24
52
63
78
Element in Array
10 24 52 63 78 
Element in Reverse Order
78 63 52 24 10
C:\Users\swapn\JAVA\Assignment_2>
*/