class expression4{
	public static void main(String[] args){
		boolean x=true;
		boolean y=false;
		boolean z;
		z=((x && y) || !(x || y));
		System.out.println("Value of z= "+z);
	}
}

/*
C:\Users\swapn\JAVA>javac expression4.java

C:\Users\swapn\JAVA>java expression4
Value of z= false

C:\Users\swapn\JAVA>
*/