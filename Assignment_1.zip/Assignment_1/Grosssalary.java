import java.util.*;

class Grosssalary
{
	public static void main(String args[])
	
	{
	Scanner sc=new Scanner(System.in);
      double sal,da,hra,da1,hra1,gsal;
	  
	System.out.println("Enter basic salary");
	sal=sc.nextDouble();
	System.out.println("Enter DA");
	da1=sc.nextDouble();
		System.out.println("Enter HRA");
	hra1=sc.nextDouble();
	
	da=(da1*sal)/100;
	hra=(hra1*sal)/100;
	
	gsal=sal+da+hra;
	
	

	System.out.println(" Gross Salary is   "+gsal);
	
	
		
	}
}

/*
C:\Users\swapn\JAVA>javac Grosssalary.java

C:\Users\swapn\JAVA>java grosssalary
Enter basic salary
15000
Enter DA
.98
Enter HRA
.10
 Gross Salary is   15162.0

C:\Users\swapn\JAVA>
*/