class Swapping{
	public static void main(String[] args){
		int a=5;
		int b=10;
		
		b=a;
		a=b+b;
		
		
		System.out.println("a = "+a+"\nb = "+b);
	}
}

/*
C:\Users\swapn\JAVA>javac Swapping.java

C:\Users\swapn\JAVA>java Swapping
a = 10
b = 5

C:\Users\swapn\JAVA>
*/