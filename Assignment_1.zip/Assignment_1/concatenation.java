import java.util.*;
class concatenation{
	public static void main(String[] args){
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the marks of subject");
		int sub1 = sc.nextInt();
		int sub2 = sc.nextInt();
		int sub3 = sc.nextInt();
		int sub4 = sc.nextInt();
		int sub5 = sc.nextInt();
		System.out.println("Obtained Marks = "+((sub1+sub2+sub3+sub4+sub5)/5)+"%");
	}
}

/*
C:\Users\swapn\JAVA>java concatenation
Enter the marks of subject
75
60
55
70
80
Obtained Marks = 68%

C:\Users\swapn\JAVA>
*/