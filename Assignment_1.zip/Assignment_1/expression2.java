class expression2{
	public static void main(String[] args){
		int x=10;
		int y;
		y=((x++) + (++x));
		System.out.println("Value of x= "+x+"\nValue of y= "+y);
	}
}

/*
C:\Users\swapn\JAVA>java expression2
Value of x= 12
Value of y= 22

C:\Users\swapn\JAVA>
*/