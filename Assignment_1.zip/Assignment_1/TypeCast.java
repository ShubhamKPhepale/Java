class TypeCast{
	public static void main(String[] args){
		byte sum;
		short a=100;
		short b=28;
		sum=(byte) (a+b);
		System.out.println("Addition is = "+sum);
	}
}

/*
C:\Users\swapn\JAVA>javac TypeCast.java

C:\Users\swapn\JAVA>java TypeCast
Addition is = -128

C:\Users\swapn\JAVA>
*/