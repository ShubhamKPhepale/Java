import java.util.*;
class CountDay{
	public static void main(String[] args){
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the no of days");
		int days = sc.nextInt();

		int years,months,day;
		
		years=days/365;
		days=days%365;

		months=days/12;
		days=days%7;
		day=days;
		
		System.out.println("No of Year = "+years+"\nNo of months = "+months+"\nNo of days = "+day);
	}
}
/*
C:\Users\swapn\JAVA>java CountDay
Enter the no of days
670
No of Year = 1
No of months = 25
No of days = 4

C:\Users\swapn\JAVA>
*/