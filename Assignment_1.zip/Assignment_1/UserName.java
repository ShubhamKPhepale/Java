import java.util.*;
class UserName{
	public static void main(String[] args){

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the name");
		String name = sc.next();
		System.out.println("User name = "+name);
	}
}
/*
C:\Users\swapn\JAVA>java UserName
Enter the name
Shubham
User name = Shubham

C:\Users\swapn\JAVA>
*/