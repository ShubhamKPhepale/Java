import java.util.*;
class Interest{
	public static void main(String[] args){
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the amount, rate and time");
		int amt = sc.nextInt();
		float rate= sc.nextFloat();
		int time=sc.nextInt();	
		float total_amt=(amt*(1+(rate*time)));
		System.out.println("Totoal Amount = "+total_amt);
	}
}

/*
C:\Users\swapn\JAVA>java Interest
Enter the amount, rate and time
5000
0.6
2
Totoal Amount = 11000.0

C:\Users\swapn\JAVA>
*/