import java.util.*;
class Grater3No{
	public static void main(String[] args){
		int a=20;
		int b=30;
		int c=25;

		
		if((a > b)&&(a >c ))
		{
			System.out.println("A is Grater than B and C");
		}
		else if((b>a)&&(b>c))
		{
			System.out.println("B is Grater than A and C");
		}
		else
		{
			System.out.println("C is Grater than A and B");
		}

		int temp= a>b ? a:b;
		int res= c>temp ? c:temp;
		System.out.println("Grater Number is "+res);
	}

}

/*
C:\Users\swapn\JAVA>javac Grater3No.java

C:\Users\swapn\JAVA>java Grater3No
B is Grater than A and C
Grater Number is 30

C:\Users\swapn\JAVA>
*/