class RollNo{
	public static void main(String[] args){
	int rollNo=100;
	System.out.println("roll no = "+rollNo);
}
}

/*

C:\Users\swapn\JAVA>javac RollNo.java

C:\Users\swapn\JAVA>java RollNo
roll no = 100

C:\Users\swapn\JAVA>

*/