import java.util.*;
class LeapYear{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the year");
		int year = sc.nextInt();	
		if((year%4==0)&&(year%100!=0)||(year%400==0))
		{
			System.out.println("Year is leap year");
		}
		else
		{
			System.out.println("Year is NOT leap year");
		}
	}

}

/*
C:\Users\swapn\JAVA>javac LeapYear.java

C:\Users\swapn\JAVA>java LeapYear
Enter the year
2020
Year is leap year

C:\Users\swapn\JAVA>java LeapYear
Enter the year
2019
Year is NOT leap year

C:\Users\swapn\JAVA>
*/