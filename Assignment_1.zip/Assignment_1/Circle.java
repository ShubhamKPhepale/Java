import java.util.*;
class Circle{
	public static void main(String[] args){
		float pi=3.14f;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the radius");
		int r = sc.nextInt();
		float area=(pi*(r*r));
		float circumference=(2*pi*r);
		
		System.out.println("Area of Circle ="+area+"\nCircumference of Circle ="+circumference);
	}
}

/*
C:\Users\swapn\JAVA>java Circle
Enter the radius
5
Area of Circle =78.5
Circumference of Circle =31.400002

C:\Users\swapn\JAVA>
*/