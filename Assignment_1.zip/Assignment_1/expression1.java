class expression1{
	public static void main(String[] args){
		int x=10;
		int y;
		y=((x*x)+(3*x)-7);
		System.out.println("Value of y= "+y);
	}
}

/*

C:\Users\swapn\JAVA>javac expression1.java

C:\Users\swapn\JAVA>java expression1
Value of y= 123

C:\Users\swapn\JAVA>

*/