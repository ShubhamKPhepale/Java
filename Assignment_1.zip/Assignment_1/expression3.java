class expression3{
	public static void main(String[] args){
		int x=10;
		int y=5;
		int z;
		z=((x++) - (--y) - (--x) + (x++));
		System.out.println("Value of x= "+x+"\nValue of y= "+y+"\nValue of z= "+z);
	}
}
/*

C:\Users\swapn\JAVA>java expression3
Value of x= 11
Value of y= 4
Value of z= 6

C:\Users\swapn\JAVA>

*/