import java.util.*;
class Temperature{
	public static void main(String[] args){
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the temperature in Fahrenheit");
		int temp_f = sc.nextInt();
		double celsius=(5*(temp_f - 32)/9);
		
		System.out.println("Temperature form Fahrenheit to Celsius= "+celsius);
	}
}

/*
C:\Users\swapn\JAVA>java Temperature
Enter the temperature in Fahrenheit
100
Temperature form Fahrenheit to Celsius= 37.0

C:\Users\swapn\JAVA>
*/