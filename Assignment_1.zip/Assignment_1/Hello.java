class Hello{
	public static void main(String args[]){
		System.out.println("Hello World!!");
	}
}
/*
C:\Users\swapn\JAVA>javac Hello.java

C:\Users\swapn\JAVA>java Hello
Hello World!!

C:\Users\swapn\JAVA>

*/